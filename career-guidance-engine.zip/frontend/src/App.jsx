import React, { useState } from 'react';

function App() {
  const [aptitude, setAptitude] = useState('');
  const [aspiration, setAspiration] = useState('');
  const [skills, setSkills] = useState('');

  const handleSubmit = () => {
    alert("In real integration, this data would be sent to the backend");
  };

  return (
    <div className="App">
      <h1>Career Guidance Form</h1>
      <input placeholder="Aptitude Scores" value={aptitude} onChange={e => setAptitude(e.target.value)} />
      <input placeholder="Aspiration" value={aspiration} onChange={e => setAspiration(e.target.value)} />
      <input placeholder="Skills" value={skills} onChange={e => setSkills(e.target.value)} />
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
}

export default App;
