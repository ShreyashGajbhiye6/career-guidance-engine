import streamlit as st
from model import recommend_career

st.title("AI-Powered Career Guidance Engine")

aptitude = st.text_input("Enter Aptitude Scores (e.g. 70,80,65)")
aspiration = st.text_input("Career Aspiration (e.g. Data Scientist)")
skills = st.text_input("Enter Skills (comma-separated)")
education = st.selectbox("Select Education Level", ["10th", "12th", "Bachelors", "Masters"])

if st.button("Get Career Guidance"):
    result = recommend_career(aptitude, aspiration, skills, education)
    st.subheader("Suggested Career Path:")
    st.success(result['career'])
    st.subheader("Skill Gap Analysis:")
    st.info(", ".join(result['skill_gaps']))
