def recommend_career(aptitude_str, aspiration, skills_str, education):
    required_skills = {
        "Software Engineer": ["programming", "data structures", "algorithms"],
        "Data Scientist": ["python", "statistics", "machine learning"],
        "UI/UX Designer": ["design", "figma", "prototyping"],
        "Cybersecurity Analyst": ["networking", "linux", "security"],
    }

    aspiration = aspiration.strip().title()
    skills = [s.strip().lower() for s in skills_str.split(",")]

    if aspiration in required_skills:
        career = aspiration
        missing = [s for s in required_skills[aspiration] if s not in skills]
    else:
        career = "Software Engineer"  # default suggestion
        missing = [s for s in required_skills["Software Engineer"] if s not in skills]

    return {
        "career": career,
        "skill_gaps": missing
    }
